import { JobListingPage } from '@/components/JobListingPage';

export default function Index() {
  return (
    <div className="min-h-screen bg-background">
      <JobListingPage />
    </div>
  );
}